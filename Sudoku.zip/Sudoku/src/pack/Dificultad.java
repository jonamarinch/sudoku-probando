package pack;

public enum Dificultad {

	REGALO, FÁCIL, MEDIO, DIFÍCIL, VACÍO;
	
}
