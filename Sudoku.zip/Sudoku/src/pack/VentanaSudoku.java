package pack;

import javax.swing.JFrame;

public class VentanaSudoku extends JFrame {
	
	VentanaSudoku(String difSelecc)
	{
		this.add(new TableroSudoku(difSelecc));
		this.setTitle("Juego - Tres en raya");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}

}
