package pack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JPanel;

public class TableroSudoku extends JPanel implements ActionListener {
	
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 600;
	Random random;
	
	TableroSudoku(String difSelecc) {
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{

	}
}
