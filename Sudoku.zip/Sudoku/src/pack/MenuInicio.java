package pack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;

public class MenuInicio extends JFrame implements ActionListener {
	
	private JPanel contentPane;
	
	Object selectedItem;
	
	public MenuInicio() {
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Empezar a jugar");
		btnNewButton.setBounds(199, 299, 200, 23);
		btnNewButton.addActionListener(this);
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(199, 382, 200, 35);
		comboBox.addItem("FACIL");
		comboBox.addItem("MEDIO");
		comboBox.addItem("DIFICIL");
		contentPane.add(comboBox);
		
		selectedItem = comboBox.getSelectedItem();
		
		JLabel lblNewLabel = new JLabel("SUDOKU");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 62));
		lblNewLabel.setBounds(83, 34, 431, 191);
		contentPane.add(lblNewLabel);
	
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		String selectedString = (String) selectedItem;
		new VentanaSudoku(selectedString);
	}
}
