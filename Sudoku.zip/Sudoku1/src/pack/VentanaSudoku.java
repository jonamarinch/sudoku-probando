package pack;

import javax.swing.JFrame;

public class VentanaSudoku extends JFrame {
	
	VentanaSudoku(String difSelecc)
	{
		this.add(new TableroSudoku(difSelecc));
		this.setTitle("Juego - Sudoku");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}
	
	@Override
	public void dispose()
	{
		this.setVisible(false);
		MenuInicio meIn = new MenuInicio();
	}

}
