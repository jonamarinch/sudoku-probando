package pack;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.Dimension;
import java.awt.FlowLayout;

public class VentanaSudoku extends JDialog implements ActionListener {
	
	private JPanel contentPane;
	private static final int SCREEN_WIDTH = 600;
	private static final int SCREEN_HEIGHT = 600;
	private final int GRID = 9;
	private Random random;
	private Enum difSelecc;
	private int[][] numerosSudoku;
	private JPanel[][] tableroSudoku;
	private JTextField[][] rellenoSudoku;
	
	VentanaSudoku(JFrame propietario, String tituloDifSelecc, Enum difSelecc)
	{
		super(propietario, tituloDifSelecc);
		this.difSelecc = difSelecc;
//		this.setTitle("Juego - Sudoku - "+ difSelecc);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(900,900);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(GRID, GRID));
		
		tableroSudoku = new JPanel[GRID][GRID];
		
		rellenoSudoku = new JTextField[GRID][GRID];
		
		numerosSudoku = new int[][] {
			{5, 3, 4, 6, 7, 8, 9, 1, 2},
			{6, 7, 2, 1, 9, 5, 3, 4, 8},
			{1, 9, 8, 3, 4, 2, 5, 6, 7},
			{8, 5, 9, 7, 6, 1, 4, 2, 3},
			{4, 2, 6, 8, 5, 3, 7, 9, 1},
			{7, 1, 3, 9, 2, 4, 8, 5, 6},
			{9, 6, 1, 5, 3, 7, 2, 8, 4},
			{2, 8, 7, 4, 1, 9, 6, 3, 5},
			{3, 4, 5, 2, 8, 6, 1, 7, 9}
		};
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	tableroSudoku[i][j] = new JPanel();
            	JPanel panel = tableroSudoku[i][j];
            	//panel.setPreferredSize(new Dimension(100, 100));
            	contentPane.add(panel);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	rellenoSudoku[i][j] = new JTextField();
            	JTextField tField = rellenoSudoku[i][j];
            	//int tFieldHeight = tField.getHeight();
            	//tField.setPreferredSize(new Dimension(20, 20));
            	tField.setOpaque(false);
            	tField.setBorder(BorderFactory.createEmptyBorder());
            	tableroSudoku[i][j].add(tField);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	rellenoSudoku[i][j].setText(String.valueOf(numerosSudoku[i][j]));
            }
        }
		
		this.setVisible(true);
	}
	
	@Override
	public void dispose()
	{
		this.setVisible(false);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
	}

}
