package pack;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

public class VentanaSudoku extends JDialog implements ActionListener {
	
	private JPanel sudokuPanel;
	private static final int SCREEN_SIZE = 900;
	private final int GRID = 9;
	private Random random;
	private Enum difSelecc;
	private int[][] numerosSudoku;
	private JPanel[][] tableroSudoku;
	private JTextField[][] rellenoSudoku;
	
	VentanaSudoku(JFrame propietario, String tituloDifSelecc, Enum difSelecc)
	{
		super(propietario, tituloDifSelecc);
		this.difSelecc = difSelecc;
//		this.setTitle("Juego - Sudoku - "+ difSelecc);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(SCREEN_SIZE,SCREEN_SIZE);
		this.setResizable(false);

		sudokuPanel = new JPanel();
		sudokuPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(sudokuPanel);
		sudokuPanel.setLayout(new GridLayout(GRID, GRID));
		sudokuPanel.setPreferredSize(new Dimension(SCREEN_SIZE, SCREEN_SIZE));
		
		tableroSudoku = new JPanel[GRID][GRID];
		
		rellenoSudoku = new JTextField[GRID][GRID];
		
		numerosSudoku = new int[][] {
			{5, 3, 4, 6, 7, 8, 9, 1, 2},
			{6, 7, 2, 1, 9, 5, 3, 4, 8},
			{1, 9, 8, 3, 4, 2, 5, 6, 7},
			{8, 5, 9, 7, 6, 1, 4, 2, 3},
			{4, 2, 6, 8, 5, 3, 7, 9, 1},
			{7, 1, 3, 9, 2, 4, 8, 5, 6},
			{9, 6, 1, 5, 3, 7, 2, 8, 4},
			{2, 8, 7, 4, 1, 9, 6, 3, 5},
			{3, 4, 5, 2, 8, 6, 1, 7, 9}
		};
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	tableroSudoku[i][j] = new JPanel();
            	JPanel panel = tableroSudoku[i][j];
            	panel.setPreferredSize(new Dimension(SCREEN_SIZE/9, SCREEN_SIZE/9));
            	Color miColor = new Color(255, 204, 153);
            	panel.setBackground(miColor);
            	// 1 borde rojo:
            	// ***
            	if (i==2 && j!=2 && j!=3 && j!=5 && j!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,1,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	} 
            	else if (i==3 && j!=2 && j!=3 && j!=5 && j!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,0,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	} 
            	else if (j==2 && i!=2 && i!=3 && i!=5 && i!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,0,1,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	} 
            	else if (j==3 && i!=2 && i!=3 && i!=5 && i!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,1,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (i==5 && j!=2 && j!=3 && j!=5 && j!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,1,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (i==6 && j!=2 && j!=3 && j!=5 && j!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,0,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==5 && i!=2 && i!=3 && i!=5 && i!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,1,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==6 && i!=2 && i!=3 && i!=5 && i!=6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,0,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	// 2 bordes rojos:
            	// ***
            	else if (i==2 && j==2)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,1,1,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (i==3 && j==2)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,0,0,1,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (i==2 && j==3)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,1,1,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (i==3 && j==3)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,1,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==2 && i==5)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,0,1,1,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==2 && i==6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,0,0,1,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==3 && i==5)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(0,1,1,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==3 && i==6)
            	{
            		panel.setBorder(new CompoundBorder(
            				BorderFactory.createMatteBorder(1,1,0,0,Color.RED),
            				BorderFactory.createMatteBorder(1,1,1,1,Color.BLACK)));
            	}
            	else if (j==5 && i==2)
            	{
            		
            	}
            	// Ningún borde rojo:
            	// ***
            	else
            	{
            		panel.setBorder(new LineBorder(Color.BLACK, 1));
            	}
            	sudokuPanel.add(panel);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	rellenoSudoku[i][j] = new JTextField();
            	JTextField tField = rellenoSudoku[i][j];
            	tField.setOpaque(false);
            	tField.setBorder(BorderFactory.createEmptyBorder(35, 35, 35, 35));
            	tableroSudoku[i][j].add(tField);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	rellenoSudoku[i][j].setText(String.valueOf(numerosSudoku[i][j]));
            }
        }
		
		this.pack();
        this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	@Override
	public void dispose()
	{
		this.setVisible(false);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
	}

}
