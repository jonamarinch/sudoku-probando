package pack;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class VentanaSudoku extends JDialog implements ActionListener {
	
	private JPanel contentPane;
	private static final int SCREEN_WIDTH = 600;
	private static final int SCREEN_HEIGHT = 600;
	private final int GRID = 9;
	private Random random;
	private String difSelecc;
	private int[][] numerosSudoku;
	private JPanel[][] tableroSudoku;
	private JTextField[][] rellenoSudoku;
	
	VentanaSudoku(String difSelecc)
	{
		this.difSelecc = difSelecc;
		this.setTitle("Juego - Sudoku");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setResizable(true);
		this.pack();
		this.setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(GRID, GRID));
		
		JTextPane txtpnWololoooooooo = new JTextPane();
		txtpnWololoooooooo.setText("wololoooooooo");
		contentPane.add(txtpnWololoooooooo);
		
		tableroSudoku = new JPanel[GRID][GRID];
		
		rellenoSudoku = new JTextField[GRID][GRID];
		
		int[][] numerosSudoku = {
				{5, 3, 4, 6, 7, 8, 9, 1, 2},
				{6, 7, 2, 1, 9, 5, 3, 4, 8},
				{1, 9, 8, 3, 4, 2, 5, 6, 7},
				{8, 5, 9, 7, 6, 1, 4, 2, 3},
				{4, 2, 6, 8, 5, 3, 7, 9, 1},
				{7, 1, 3, 9, 2, 4, 8, 5, 6},
				{9, 6, 1, 5, 3, 7, 2, 8, 4},
				{2, 8, 7, 4, 1, 9, 6, 3, 5},
				{3, 4, 5, 2, 8, 6, 1, 7, 9}
		};
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	tableroSudoku[i][j] = new JPanel();
            	JPanel panel = tableroSudoku[i][j];
            	contentPane.add(panel);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
            	rellenoSudoku[i][j] = new JTextField();
            	tableroSudoku[i][j].add(rellenoSudoku[i][j]);
            }
		}
		
		for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
//            	rellenoSudoku[i][j].setText(String.valueOf(numerosSudoku[i][j]));
            	rellenoSudoku[i][j].setText("***");
            }
        }
		
		this.setVisible(true);
	}
	
	@Override
	public void dispose()
	{
		this.setVisible(false);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
	}

}
