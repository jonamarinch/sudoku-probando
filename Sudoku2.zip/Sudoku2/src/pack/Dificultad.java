package pack;

public enum Dificultad {

	FACIL, MEDIO, DIFICIL;
	
//	public static Dificultad getDificultad(String instruction) {
//        switch (instruction.toLowerCase()) {
//            case "facil":
//                return FACIL;
//            case "medio":
//                return MEDIO;
//            case "dificil":
//                return DIFICIL;
//            default:
//                throw new IllegalArgumentException("Invalid instruction: " + instruction);
//        }
//    }
}
